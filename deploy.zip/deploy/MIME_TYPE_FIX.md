# 🚨 TROUBLESHOOTING - MIME Type Error

## ❌ **Error yang Terjadi:**
```
Symfony\Component\Mime\Exception\LogicException
Unable to guess the MIME type as no guessers are available 
(have you enabled the php_fileinfo extension?).
```

## ✅ **Solusi yang Sudah Diterapkan:**

### 1. **File php.ini** (di laravel-api/)
- Menambahkan `extension=fileinfo`
- Konfigurasi memory dan upload limits
- Security settings

### 2. **MIME Fix Bootstrap** (laravel-api/bootstrap/mime_fix.php)
- Fallback MIME types jika fileinfo tidak tersedia
- Override fungsi mime_content_type
- Default content type header

### 3. **Updated .htaccess**
- Force enable fileinfo via mod_php
- Security headers tambahan

### 4. **Production .env**
- APP_DEBUG=false
- LOG_LEVEL=error
- SESSION_PATH=/api
- SESSION_DOMAIN=itlab.unila.ac.id

## 🔧 **Langkah Manual di cPanel:**

### Opsi 1: Aktifkan php_fileinfo
1. Login ke cPanel
2. Cari "PHP Selector" atau "Select PHP Version"
3. Klik "Extensions"
4. Centang "fileinfo"
5. Save

### Opsi 2: Upload php.ini Custom
1. Upload file `php.ini` ke folder `laravel-api/`
2. Restart aplikasi

### Opsi 3: Hubungi Support Hosting
Jika masih error, minta hosting provider untuk mengaktifkan:
- `php_fileinfo` extension
- `php_mime_magic` extension

## 🧪 **Test Setelah Fix:**

1. **Check Extensions**: `https://itlab.unila.ac.id/api/test.php`
2. **Main App**: `https://itlab.unila.ac.id/api`

## 📞 **Jika Masih Error:**

### Check PHP Info:
Buat file `info.php` di `public_html/api/`:
```php
<?php phpinfo(); ?>
```

Akses: `https://itlab.unila.ac.id/api/info.php`
Cari section "fileinfo" - harus enabled.

### Alternative: Disable MIME Detection
Edit file config Laravel jika semua gagal:
- `config/filesystems.php`
- Set `'disable_mime_detection' => true`
