<?php
// Alternative index.php yang bypass MIME detection
use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Set environment untuk disable MIME detection
$_ENV['DISABLE_MIME_DETECTION'] = '1';
putenv('DISABLE_MIME_DETECTION=1');

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../../laravel-api/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require __DIR__.'/../../laravel-api/vendor/autoload.php';

// Monkey patch untuk Symfony MimeTypes jika diperlukan
if (class_exists('Symfony\Component\Mime\MimeTypes')) {
    // Override method yang bermasalah
    try {
        $reflection = new ReflectionClass('Symfony\Component\Mime\MimeTypes');
        if ($reflection->hasMethod('isGuesserSupported')) {
            // Kita akan handle ini di level aplikasi Laravel
        }
    } catch (Exception $e) {
        // Silent fail
    }
}

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../../laravel-api/bootstrap/app.php';

$app->handleRequest(Request::capture());
