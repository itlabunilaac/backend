<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// CRITICAL: Load Symfony patch FIRST before any autoloading
require_once __DIR__.'/../../laravel-api/bootstrap/symfony_mime_patch.php';

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../../laravel-api/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require __DIR__.'/../../laravel-api/vendor/autoload.php';

// Load our MIME fix after autoloader
require_once __DIR__.'/../../laravel-api/bootstrap/mime_fix.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../../laravel-api/bootstrap/app.php';

$app->handleRequest(Request::capture());
