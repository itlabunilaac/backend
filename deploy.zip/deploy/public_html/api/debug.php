<?php
// Debug file untuk check server configuration
header('Content-Type: text/html; charset=UTF-8');

echo "<h1>Server Debug Info</h1>";

echo "<h2>PHP Extensions</h2>";
echo "<strong>fileinfo extension:</strong> " . (extension_loaded('fileinfo') ? 'ENABLED ✅' : 'DISABLED ❌') . "<br>";
echo "<strong>mime_magic extension:</strong> " . (extension_loaded('mime_magic') ? 'ENABLED ✅' : 'DISABLED ❌') . "<br>";
echo "<strong>finfo functions:</strong> " . (function_exists('finfo_open') ? 'AVAILABLE ✅' : 'NOT AVAILABLE ❌') . "<br>";

echo "<h2>MIME Functions</h2>";
echo "<strong>mime_content_type:</strong> " . (function_exists('mime_content_type') ? 'AVAILABLE ✅' : 'NOT AVAILABLE ❌') . "<br>";
echo "<strong>finfo_file:</strong> " . (function_exists('finfo_file') ? 'AVAILABLE ✅' : 'NOT AVAILABLE ❌') . "<br>";

echo "<h2>Server Info</h2>";
echo "<strong>PHP Version:</strong> " . PHP_VERSION . "<br>";
echo "<strong>Server Software:</strong> " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown') . "<br>";
echo "<strong>Document Root:</strong> " . ($_SERVER['DOCUMENT_ROOT'] ?? 'Unknown') . "<br>";

echo "<h2>Environment Check</h2>";
echo "<strong>Current Directory:</strong> " . getcwd() . "<br>";
echo "<strong>Laravel App Path:</strong> " . realpath(__DIR__ . '/../../laravel-api') . "<br>";
echo "<strong>.env exists:</strong> " . (file_exists(__DIR__ . '/../../laravel-api/.env') ? 'YES ✅' : 'NO ❌') . "<br>";
echo "<strong>vendor exists:</strong> " . (file_exists(__DIR__ . '/../../laravel-api/vendor') ? 'YES ✅' : 'NO ❌') . "<br>";

echo "<h2>Error Testing</h2>";
try {
    require_once __DIR__ . '/../../laravel-api/vendor/autoload.php';
    echo "<strong>Autoloader:</strong> LOADED ✅<br>";
} catch (Exception $e) {
    echo "<strong>Autoloader Error:</strong> " . $e->getMessage() . " ❌<br>";
}

echo "<hr>";
echo "<small>Debug Time: " . date('Y-m-d H:i:s') . "</small>";
?>
