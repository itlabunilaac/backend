<?php
// Emergency bypass index.php 
// Ini akan bypass semua MIME detection

// Disable all error reporting first
error_reporting(0);
ini_set('display_errors', 0);

// Set basic headers
header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

define('LARAVEL_START', microtime(true));

try {
    // Set environment to disable MIME detection
    $_ENV['SYMFONY_DEPRECATIONS_HELPER'] = 'disabled';
    $_ENV['DISABLE_MIME_DETECTION'] = '1';
    putenv('DISABLE_MIME_DETECTION=1');
    
    // Register shutdown function to catch fatal errors
    register_shutdown_function(function() {
        $error = error_get_last();
        if ($error && $error['type'] === E_ERROR) {
            if (strpos($error['message'], 'MIME') !== false || strpos($error['message'], 'fileinfo') !== false) {
                header('Content-Type: application/json');
                echo json_encode([
                    'error' => 'MIME detection not supported on this server',
                    'message' => 'Please contact hosting provider to enable fileinfo extension',
                    'solution' => 'Or downgrade to Laravel 10.x',
                    'server_info' => [
                        'php_version' => PHP_VERSION,
                        'extensions' => get_loaded_extensions()
                    ]
                ]);
                exit;
            }
        }
    });
    
    // Check if maintenance mode
    if (file_exists($maintenance = __DIR__.'/../../laravel-api/storage/framework/maintenance.php')) {
        require $maintenance;
    }
    
    // Load autoloader
    if (!file_exists(__DIR__.'/../../laravel-api/vendor/autoload.php')) {
        throw new Exception('Vendor autoload not found. Run composer install.');
    }
    
    require __DIR__.'/../../laravel-api/vendor/autoload.php';
    
    // Bootstrap Laravel
    $app = require_once __DIR__.'/../../laravel-api/bootstrap/app.php';
    
    // Handle request
    $app->handleRequest(Illuminate\Http\Request::capture());
    
} catch (Throwable $e) {
    // Catch any error and return JSON response
    header('Content-Type: application/json');
    http_response_code(500);
    
    echo json_encode([
        'error' => 'Application Error',
        'message' => $e->getMessage(),
        'type' => get_class($e),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'suggestion' => 'Check server logs or contact administrator'
    ]);
}
?>
