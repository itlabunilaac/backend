# 🚀 E-JOURNAL API DEPLOYMENT PACKAGE

## 📁 Struktur Deploy yang Sudah Dibuat:

```
deploy/
├── laravel-api/              # 📱 Aplikasi Laravel untuk server
│   └── .env                  # ⚙️ Konfigurasi production
├── public_html/
│   └── api/                  # 🌐 Public files untuk web
│       ├── index.php         # 🏠 Entry point
│       ├── .htaccess         # 🔧 URL rewriting
│       └── test.php          # 🧪 Test endpoint
├── deploy.bat                # 🛠️ Script deployment
├── deploy_exclude.txt        # 📋 Files yang tidak di-deploy
└── DEPLOYMENT_GUIDE.md       # 📖 Panduan lengkap
```

## 🎯 Target Production:

- **Domain**: `itlab.unila.ac.id/api`
- **Laravel App**: `/home/itlabunilaacid/laravel-api/`
- **Public Files**: `/home/itlabunilaacid/public_html/api/`

## ⚡ Quick Start:

1. **Run Deploy Script**:
   ```cmd
   cd c:\laragon\www\backend-1\deploy
   deploy.bat
   ```

2. **Upload Files**:
   - Zip `laravel-api/` → Upload ke cPanel → Extract ke `/laravel-api/`
   - Upload `public_html/api/` → Ke `/public_html/api/`

3. **Setup Database**:
   - Buat database: `itlabunilaacid_e_journal`
   - Update credentials di `.env`

4. **Run Commands** (di server):
   ```bash
   php artisan migrate --force
   php artisan config:cache
   ```

## 🔍 Testing URLs:

- **Local**: `http://localhost/backend-1/e-journal/public`
- **Production**: `https://itlab.unila.ac.id/api`
- **Test Endpoint**: `https://itlab.unila.ac.id/api/test.php`

## ⚠️ Important Notes:

- Set `APP_DEBUG=false` di production
- Update database credentials
- Set proper file permissions (755/644)
- Make sure HTTPS is enabled

---

✅ **Ready to Deploy!** Follow DEPLOYMENT_GUIDE.md for detailed instructions.
