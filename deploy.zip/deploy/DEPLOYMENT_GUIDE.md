# DEPLOYMENT GUIDE - E-JOURNAL API

## Struktur Server Production

```
/home/itlabunilaacid/
├── laravel-api/                    # Aplikasi Laravel (di luar public_html)
│   ├── app/
│   ├── bootstrap/
│   ├── config/
│   ├── database/
│   ├── routes/
│   ├── storage/
│   ├── vendor/
│   ├── .env                        # File konfigurasi production
│   └── artisan
│
└── public_html/
    └── api/                        # Public folder Laravel
        ├── index.php               # Entry point yang mengarah ke laravel-api/
        └── .htaccess              # URL rewriting rules
```

## URL Structure
- **Base URL**: `https://itlab.unila.ac.id/api`
- **API Endpoints**: `https://itlab.unila.ac.id/api/api/...`

## Deployment Steps

### 1. Persiapan Files
```bash
# Jalankan script deployment
cd c:\laragon\www\backend-1\deploy
deploy.bat
```

### 2. Upload ke cPanel
1. **Upload laravel-api folder**:
   - Compress folder `deploy/laravel-api/`
   - Upload ke cPanel File Manager
   - Extract ke direktori `/home/itlabunilaacid/laravel-api/`

2. **Upload public files**:
   - Upload isi folder `deploy/public_html/api/`
   - Ke direktori `/home/itlabunilaacid/public_html/api/`

### 3. Database Setup
1. Buat database di cPanel:
   - Nama: `itlabunilaacid_e_journal`
   - User: `itlabunilaacid_db_user`
   - Password: [strong password]

2. Update file `.env` di server:
   ```env
   DB_DATABASE=itlabunilaacid_e_journal
   DB_USERNAME=itlabunilaacid_db_user
   DB_PASSWORD=[your_password]
   ```

### 4. Permissions Setup
```bash
# Set permissions via cPanel Terminal atau SSH
chmod -R 755 /home/itlabunilaacid/laravel-api/
chmod -R 775 /home/itlabunilaacid/laravel-api/storage/
chmod -R 775 /home/itlabunilaacid/laravel-api/bootstrap/cache/
chmod 644 /home/itlabunilaacid/public_html/api/.htaccess
```

### 5. Laravel Optimization (via Terminal/SSH)
```bash
cd /home/itlabunilaacid/laravel-api/

# Install production dependencies
composer install --no-dev --optimize-autoloader

# Generate new APP_KEY if needed
php artisan key:generate --force

# Cache optimization
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan optimize

# Run migrations
php artisan migrate --force

# Seed database (if needed)
php artisan db:seed --force
```

## Testing

### Local Testing
```
http://localhost/backend-1/e-journal/public/api/test
```

### Production Testing
```
https://itlab.unila.ac.id/api/api/test
```

## Security Considerations

1. **Environment File**: Pastikan `.env` tidak dapat diakses dari web
2. **Debug Mode**: Set `APP_DEBUG=false` di production
3. **HTTPS**: Pastikan menggunakan HTTPS
4. **Database**: Gunakan password yang kuat
5. **File Permissions**: Jangan set 777, gunakan 755/644

## Troubleshooting

### Error 500
1. Check Laravel logs: `/laravel-api/storage/logs/laravel.log`
2. Check server error logs di cPanel
3. Pastikan permissions benar

### Database Connection Error
1. Verify database credentials di `.env`
2. Test koneksi database di cPanel
3. Pastikan database user memiliki privileges

### Route Not Found
1. Check `.htaccess` di `/public_html/api/`
2. Pastikan mod_rewrite enabled
3. Clear route cache: `php artisan route:clear`

## Maintenance

### Update Application
1. Upload files baru ke `laravel-api/`
2. Run optimizations
3. Clear caches jika diperlukan

### Backup
- Database: Export via phpMyAdmin
- Files: Download `laravel-api/` folder
