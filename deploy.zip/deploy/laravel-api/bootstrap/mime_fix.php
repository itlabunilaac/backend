<?php
// MIME Type Fix untuk Server tanpa fileinfo extension
// Harus diload sebelum Laravel bootstrap

// Disable error reporting untuk fungsi ini
$originalErrorReporting = error_reporting(0);

try {
    // Check jika Symfony MimeTypes class sudah ada
    if (!class_exists('Symfony\Component\Mime\MimeTypes', false)) {
        // Belum ada, kita buat fallback
        if (!function_exists('mime_content_type')) {
            function mime_content_type($filename) {
                $mimeTypes = [
                    'css' => 'text/css',
                    'js' => 'application/javascript',
                    'json' => 'application/json',
                    'html' => 'text/html',
                    'htm' => 'text/html',
                    'txt' => 'text/plain',
                    'xml' => 'application/xml',
                    'pdf' => 'application/pdf',
                    'jpg' => 'image/jpeg',
                    'jpeg' => 'image/jpeg',
                    'png' => 'image/png',
                    'gif' => 'image/gif',
                    'svg' => 'image/svg+xml',
                    'zip' => 'application/zip',
                ];
                
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                return isset($mimeTypes[$ext]) ? $mimeTypes[$ext] : 'application/octet-stream';
            }
        }
    }
    
    // Set environment variable untuk disable MIME detection
    $_ENV['DISABLE_MIME_DETECTION'] = '1';
    putenv('DISABLE_MIME_DETECTION=1');
    
} catch (Exception $e) {
    // Silent fail
} finally {
    // Restore error reporting
    error_reporting($originalErrorReporting);
}

// Override Symfony MIME detection jika memungkinkan
if (function_exists('class_alias') && !class_exists('SymfonyMimeTypesFallback', false)) {
    class SymfonyMimeTypesFallback {
        public function guessMimeType($path) {
            return 'application/octet-stream';
        }
        
        public function isGuesserSupported() {
            return false;
        }
    }
}
?>
