<?php
// Monkey Patch untuk Symfony MIME Component
// File: laravel-api/bootstrap/symfony_mime_patch.php

// Backup original autoloader
$originalAutoload = function($class) {
    // Do nothing - fallback
};

// Register our patch before anything else loads
spl_autoload_register(function($class) {
    if ($class === 'Symfony\\Component\\Mime\\MimeTypes') {
        // Create a mock class that doesn't fail
        if (!class_exists($class, false)) {
            eval('
            namespace Symfony\\Component\\Mime;
            
            class MimeTypes {
                public function guessMimeType($path) {
                    // Always return a safe default
                    return "application/octet-stream";
                }
                
                public function isGuesserSupported() {
                    // Always return false to skip MIME detection
                    return false;
                }
                
                public function getMimeTypes($ext = null) {
                    return ["application/octet-stream"];
                }
                
                public function getExtensions($mimeType = null) {
                    return ["bin"];
                }
            }
            ');
        }
        return true;
    }
    return false;
}, true, true); // Prepend = true, throw = true

// Additional fallback for finfo functions
if (!function_exists('finfo_open')) {
    function finfo_open($options = null, $magic_file = null) {
        return false;
    }
}

if (!function_exists('finfo_file')) {
    function finfo_file($finfo, $file_name, $options = null) {
        return 'application/octet-stream';
    }
}

if (!function_exists('mime_content_type')) {
    function mime_content_type($filename) {
        return 'application/octet-stream';
    }
}
?>
